// ==UserScript==
// @name MMS Alert (Android Messages For Web)
// @version 1
// @namespace http://junebeetle.github.io
// @match *messages.android.com*
// ==/UserScript==

const CHAR_LIMIT=765;
const CHANGE_BACKGROUND=true;

setInterval(checkLength,100);

function checkLength()
{
	var inputBox=document.getElementsByClassName("CfnJU HYJSvd")[0];
	var smsText=document.getElementsByClassName("kf6XZb")[1];
	
	var charCount=inputBox.innerText.length;
	var charsRemaining=CHAR_LIMIT-charCount;
	
	if(charsRemaining<0)
	{
		smsText.innerHTML="MMS<br><span style=\"color:#FF0000;font-size:8px\">"+charsRemaining+"</span>";
		if(CHANGE_BACKGROUND)
		{
			inputBox.parentElement.style.background="rgba(255,0,0,0.2)";
		}
	}
	else
	{
		smsText.innerHTML="SMS<br><span style=\"color:#00BB00;font-size:8px\">"+charsRemaining+"</span>";
		if(CHANGE_BACKGROUND)
		{
			inputBox.parentElement.style.background="";
		}
	}
}
